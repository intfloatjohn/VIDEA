Require:
0.A linux system
1.Vim
2.GCC
3.JDK
